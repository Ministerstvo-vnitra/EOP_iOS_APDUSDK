//
//  APDUSDK.h
//  APDUSDK
//
//  Created by Jakub Mejtský on 30/10/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for APDUSDK.
FOUNDATION_EXPORT double APDUSDKVersionNumber;

//! Project version string for APDUSDK.
FOUNDATION_EXPORT const unsigned char APDUSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <APDUSDK/PublicHeader.h>


